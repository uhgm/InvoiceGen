# -*- coding: utf-8 -*-
"""
アップデート機能（GitHubで配布したZIPをチェック・適用する）。

■ 開発者（息子さん）向けメモ
  そんなにガチな仕組みではなく、GitHub上に置いた1つのJSONファイルと
  1つのZIPファイルを見に行くだけのシンプルな仕組みです。

  【最初の1回だけ行う設定】
    1. GitHubに公開リポジトリ（Public repository）を1つ作る
       例：https://github.com/あなたのアカウント/invoice-tool-updates

    2. リポジトリ直下に "version.json" というファイルを置く。中身は下記の形式：

        {
          "version": "1.1",
          "zip_url": "https://raw.githubusercontent.com/あなたのアカウント/invoice-tool-updates/main/invoice_generator_tool.zip",
          "notes": "会社印の位置を調整しました"
        }

    3. 修正したアプリ一式（invoice_generator.py, pdf_builder.py,
       updater.py, assets/ など）を "invoice_generator_tool.zip" という
       名前でZIP化し、同じリポジトリに置く。
       ※ ZIPの中に余計なフォルダを1枚かませても、かまさなくても
         どちらでも大丈夫です（自動で判定します）。

    4. invoice_generator.py の中の UPDATE_MANIFEST_URL を、
       手順2の version.json の「Raw」URLに書き換える。
       （GitHub上でファイルを開き、「Raw」ボタンを右クリック→
        「リンクのアドレスをコピー」で取得できます）

  【2回目以降・更新を配布したいとき】
    a. 手元でファイルを修正する
    b. invoice_generator.py の APP_VERSION_NUM を上げる（例："1.0" → "1.1"）
    c. アプリ一式を再度ZIP化して、GitHubの invoice_generator_tool.zip を置き換える
    d. version.json の "version" を同じ番号に書き換えて、"notes" に
       今回の変更点を一言書く
    e. あとは事務所側で、アプリの「アップデート確認」ボタンを押して
       もらうだけで、最新版が自動的に適用されます。
"""
import json
import os
import shutil
import tempfile
import urllib.request
import zipfile

TIMEOUT_CHECK = 10
TIMEOUT_DOWNLOAD = 60

# 更新のときに上書きしない（母が入力した設定・データを守るため）
PRESERVE_NAMES = {"invoice_config.json", "__pycache__", ".git"}


class UpdateError(Exception):
    pass


def parse_version(v):
    """'1.10.2' のようなバージョン文字列を (1, 10, 2) のタプルに変換して比較できるようにする。"""
    parts = []
    for p in str(v).split("."):
        digits = "".join(ch for ch in p if ch.isdigit())
        parts.append(int(digits) if digits else 0)
    return tuple(parts) if parts else (0,)


def is_configured(manifest_url: str) -> bool:
    if not manifest_url:
        return False
    placeholder_markers = ["USERNAME", "REPO", "あなたのアカウント", "your-username"]
    return not any(m in manifest_url for m in placeholder_markers)


def check_for_update(manifest_url: str) -> dict:
    """version.json を取得して {version, zip_url, notes} を返す。失敗時は UpdateError を投げる。"""
    try:
        req = urllib.request.Request(manifest_url, headers={"User-Agent": "invoice-tool-updater"})
        with urllib.request.urlopen(req, timeout=TIMEOUT_CHECK) as resp:
            raw = resp.read().decode("utf-8")
        data = json.loads(raw)
    except Exception as e:
        raise UpdateError(f"更新情報の取得に失敗しました：{e}")

    if "version" not in data or "zip_url" not in data:
        raise UpdateError("version.json の内容が正しくありません（version / zip_url が必要です）")
    return data


def download_and_apply_update(zip_url: str, app_dir: str) -> None:
    """ZIPをダウンロードして展開し、app_dir に上書きする。失敗時は UpdateError を投げる。"""
    try:
        with tempfile.TemporaryDirectory(prefix="invoice_update_") as tmp:
            zip_path = os.path.join(tmp, "update.zip")
            req = urllib.request.Request(zip_url, headers={"User-Agent": "invoice-tool-updater"})
            with urllib.request.urlopen(req, timeout=TIMEOUT_DOWNLOAD) as resp, open(zip_path, "wb") as f:
                shutil.copyfileobj(resp, f)

            extract_dir = os.path.join(tmp, "extracted")
            os.makedirs(extract_dir, exist_ok=True)
            with zipfile.ZipFile(zip_path) as zf:
                zf.extractall(extract_dir)

            # ZIPの直下が単一フォルダだけの場合は、その中身を本体とみなす
            entries = [e for e in os.listdir(extract_dir) if not e.startswith("__MACOSX")]
            if len(entries) == 1 and os.path.isdir(os.path.join(extract_dir, entries[0])):
                source_root = os.path.join(extract_dir, entries[0])
            else:
                source_root = extract_dir

            _copy_tree_overwrite(source_root, app_dir)
    except UpdateError:
        raise
    except Exception as e:
        raise UpdateError(f"更新の適用に失敗しました：{e}")


def _copy_tree_overwrite(src: str, dst: str) -> None:
    os.makedirs(dst, exist_ok=True)
    for name in os.listdir(src):
        if name in PRESERVE_NAMES:
            continue
        s = os.path.join(src, name)
        d = os.path.join(dst, name)
        if os.path.isdir(s):
            _copy_tree_overwrite(s, d)
        else:
            shutil.copy2(s, d)
