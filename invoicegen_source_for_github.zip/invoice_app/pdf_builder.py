# -*- coding: utf-8 -*-
"""
請求書PDFの描画処理。
invoice_generator.py から呼び出される。
"""
import os
import datetime

from reportlab.lib.pagesizes import A4
from reportlab.pdfgen import canvas
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib.utils import ImageReader

# 日本語フォントは、どのPCで開いても同じ見た目になるように
# フォントファイルをPDFに埋め込む方式にしている（IPAフォント／IPAフォントライセンスv1.0）。
_THIS_DIR = os.path.dirname(os.path.abspath(__file__))
_FONT_PATH = os.path.join(_THIS_DIR, "assets", "ipag.ttf")

FONT_NAME = "IPAGothic"
FONT_MIN = "IPAGothic"  # 現状は1書体のみ埋め込み、明朝の代わりにも同じ書体を使用

if not pdfmetrics.getRegisteredFontNames() or FONT_NAME not in pdfmetrics.getRegisteredFontNames():
    if os.path.exists(_FONT_PATH):
        pdfmetrics.registerFont(TTFont(FONT_NAME, _FONT_PATH))
    else:
        # フォントファイルが見つからない場合は、PDFビューア側のフォントに頼る
        from reportlab.pdfbase.cidfonts import UnicodeCIDFont
        FONT_NAME = "HeiseiKakuGo-W5"
        FONT_MIN = "HeiseiMin-W3"
        pdfmetrics.registerFont(UnicodeCIDFont(FONT_NAME))
        pdfmetrics.registerFont(UnicodeCIDFont(FONT_MIN))

PAGE_W, PAGE_H = A4
MARGIN_L = 15 * 2.83465  # 15mm を pt に
MARGIN_R = 15 * 2.83465
CONTENT_W = PAGE_W - MARGIN_L - MARGIN_R


def to_reiwa(dt: datetime.date) -> str:
    reiwa_year = dt.year - 2018
    if dt.year < 2019:
        return f"{dt.year}年{dt.month}月{dt.day}日"
    if reiwa_year == 1:
        return f"令和元年{dt.month}月{dt.day}日"
    return f"令和{reiwa_year}年{dt.month}月{dt.day}日"


def fmt_yen(v):
    try:
        return "￥{:,}".format(int(round(float(v))))
    except Exception:
        return "￥0"


def spaced(text, gap="　"):
    """文字の間に全角スペースを入れて、見出し風に広げる。"""
    return gap.join(list(text))


def draw_bold_centred(c, x, y, text, font, size):
    """1書体しかない場合に、少しずらして重ね書きすることで太字風にする。"""
    c.setFont(font, size)
    for dx, dy in [(0, 0), (0.4, 0), (0, 0.4), (0.4, 0.4)]:
        c.drawCentredString(x + dx, y + dy, text)


def build_invoice_pdf(save_path, data: dict):
    c = canvas.Canvas(save_path, pagesize=A4)
    c.setTitle("請求書")

    x0 = MARGIN_L
    x1 = PAGE_W - MARGIN_R
    y = PAGE_H - 20 * 2.83465

    # ---------------- タイトル ----------------
    draw_bold_centred(c, PAGE_W / 2, y, spaced("請求書"), FONT_NAME, 22)
    y -= 34

    # ---------------- 発行日（右上） ----------------
    date_str = to_reiwa(data["issue_date"])
    c.setFont(FONT_MIN, 11)
    c.drawRightString(x1, y, date_str)
    y -= 26

    # ---------------- 宛先 + 御中 + 印鑑 ----------------
    dest_top = y
    c.setFont(FONT_NAME, 15)
    dest_name = data.get("dest_name", "")
    c.drawString(x0, y, dest_name)
    # 「御中」は宛先名の右側、少し離して配置
    text_w = c.stringWidth(dest_name, FONT_NAME, 15)
    onchu_x = x0 + text_w + 14
    c.setFont(FONT_NAME, 15)
    c.drawString(onchu_x, y, "御中")

    # 印鑑画像を「御中」に重ねて印字
    seal_path = data.get("seal_path")
    if seal_path and os.path.exists(seal_path):
        try:
            img = ImageReader(seal_path)
            iw, ih = img.getSize()
            seal_size = 46
            # 御中の文字の少し右上に重なるように配置
            seal_x = onchu_x + 6
            seal_y = y - 6
            c.saveState()
            c.drawImage(
                img, seal_x, seal_y, width=seal_size, height=seal_size * ih / iw,
                mask="auto", preserveAspectRatio=True,
            )
            c.restoreState()
        except Exception:
            pass

    y -= 20
    c.setFont(FONT_MIN, 10.5)
    if data.get("dest_zip"):
        c.drawString(x0, y, f"〒{data['dest_zip']}　{data.get('dest_addr', '')}")
        y -= 15
    elif data.get("dest_addr"):
        c.drawString(x0, y, data.get("dest_addr", ""))
        y -= 15
    if data.get("dest_tel"):
        c.drawString(x0, y, f"電話　{data['dest_tel']}")
        y -= 15
    if data.get("dest_fax"):
        c.drawString(x0, y, f"FAX　{data['dest_fax']}")
        y -= 15

    y -= 6
    c.setFont(FONT_MIN, 11)
    c.drawString(x0, y, "下記の通りご請求申し上げます")
    y -= 22

    # ---------------- 税込合計金額 ----------------
    c.setFont(FONT_NAME, 13)
    c.drawString(x0, y, f"税込合計金額　{fmt_yen(data.get('total', 0))}")
    y -= 20

    # ---------------- 請求元（発行者） ----------------
    if data.get("issuer_name"):
        c.setFont(FONT_MIN, 10.5)
        c.drawRightString(x1, y + 20, f"請求元：{data['issuer_name']}")

    # ---------------- 明細テーブル ----------------
    table_top = y
    col_widths = [58, CONTENT_W - 58 - 40 - 60 - 70 - 55 - 90, 40, 60, 70, 55, 90]
    headers = ["日付", "品　名", "数量", "単価", "金額", "消費税", "摘要"]
    row_h = 20
    n_rows = max(10, len(data.get("items", [])) + 2)
    table_h = row_h * (n_rows + 2)  # +ヘッダー行 +合計行
    table_bottom = table_top - table_h

    c.setLineWidth(0.8)
    # 外枠
    c.rect(x0, table_bottom, CONTENT_W, table_h, stroke=1, fill=0)

    # 縦線
    xc = x0
    xs = [x0]
    for w in col_widths:
        xc += w
        xs.append(xc)
    for xline in xs[1:-1]:
        c.line(xline, table_bottom, xline, table_top)

    # ヘッダー行
    header_y = table_top - row_h
    c.line(x0, header_y, x1, header_y)
    c.setFont(FONT_NAME, 10)
    for i, htext in enumerate(headers):
        cx = (xs[i] + xs[i + 1]) / 2
        c.drawCentredString(cx, header_y + 6, htext)

    # データ行
    c.setFont(FONT_MIN, 10)
    cur_y = header_y
    items = data.get("items", [])
    for row_idx in range(n_rows):
        row_top = cur_y
        row_bottom = cur_y - row_h
        c.line(x0, row_bottom, x1, row_bottom)
        if row_idx < len(items):
            it = items[row_idx]
            vals = [
                it.get("date", ""),
                it.get("name", ""),
                it.get("qty", ""),
                (fmt_yen(it["price"]) if it.get("price") not in (None, "") else ""),
                fmt_yen(it.get("amount", 0)),
                (fmt_yen(it["tax"]) if it.get("tax") else ""),
                it.get("note", ""),
            ]
            for i, v in enumerate(vals):
                cx0, cx1 = xs[i], xs[i + 1]
                if i in (1, 6):  # 品名・摘要は左寄せ
                    c.drawString(cx0 + 4, row_bottom + 6, str(v)[:26])
                else:
                    c.drawCentredString((cx0 + cx1) / 2, row_bottom + 6, str(v))
        cur_y = row_bottom

    # 合計行
    total_row_top = cur_y
    total_row_bottom = total_row_top - row_h
    c.line(x0, total_row_bottom, x1, total_row_bottom)
    c.setFont(FONT_NAME, 11)
    c.drawCentredString((xs[0] + xs[1]) / 2, total_row_bottom + 6, "合計")
    total_amount = sum(
        float(it.get("amount", 0) or 0) + float(it.get("tax") or 0) for it in items
    )
    c.drawRightString(xs[5] - 4, total_row_bottom + 6, fmt_yen(total_amount))

    y = total_row_bottom - 24

    # ---------------- 備考欄 ----------------
    remarks_h = 46
    c.setFont(FONT_NAME, 10)
    c.drawString(x0, y, "備考欄")
    c.rect(x0, y - remarks_h - 4, CONTENT_W, remarks_h, stroke=1, fill=0)
    if data.get("remarks"):
        c.setFont(FONT_MIN, 9.5)
        _draw_wrapped_text(c, data["remarks"], x0 + 6, y - 16, CONTENT_W - 12, 12, FONT_MIN, 9.5)
    y = y - remarks_h - 24

    # ---------------- 振込先 ----------------
    c.setFont(FONT_NAME, 11)
    c.drawString(x0, y, "振込先")
    y -= 16
    c.setFont(FONT_MIN, 10)
    if data.get("bank_holder1"):
        c.drawString(x0 + 20, y, f"名義人：{data['bank_holder1']}")
        y -= 15
    if data.get("bank_holder2"):
        c.drawString(x0 + 20, y, data["bank_holder2"])
        y -= 15

    banks = data.get("banks", [])
    if banks:
        y -= 4
        b_col_widths = [140, 90, 55, 60, CONTENT_W - 140 - 90 - 55 - 60]
        b_headers = ["金融機関名", "支店名", "店番", "口座種類", "口座番号"]
        b_row_h = 20
        b_table_top = y
        b_table_h = b_row_h * (len(banks) + 1)
        b_table_bottom = b_table_top - b_table_h

        c.rect(x0, b_table_bottom, CONTENT_W, b_table_h, stroke=1, fill=0)
        bxc = x0
        bxs = [x0]
        for w in b_col_widths:
            bxc += w
            bxs.append(bxc)
        for xline in bxs[1:-1]:
            c.line(xline, b_table_bottom, xline, b_table_top)

        header_y2 = b_table_top - b_row_h
        c.line(x0, header_y2, x1, header_y2)
        c.setFont(FONT_NAME, 10)
        for i, htext in enumerate(b_headers):
            cx = (bxs[i] + bxs[i + 1]) / 2
            c.drawCentredString(cx, header_y2 + 6, htext)

        c.setFont(FONT_MIN, 10)
        cur_y2 = header_y2
        for bank in banks:
            row_bottom = cur_y2 - b_row_h
            c.line(x0, row_bottom, x1, row_bottom)
            vals = [bank.get("name", ""), bank.get("branch", ""), bank.get("code", ""),
                    bank.get("type", ""), bank.get("number", "")]
            for i, v in enumerate(vals):
                cx = (bxs[i] + bxs[i + 1]) / 2
                c.drawCentredString(cx, row_bottom + 6, str(v))
            cur_y2 = row_bottom
        y = b_table_bottom - 10

    c.showPage()
    c.save()


def _draw_wrapped_text(c, text, x, y, max_width, line_height, font, size):
    c.setFont(font, size)
    line = ""
    cur_y = y
    for ch in text:
        if ch == "\n":
            c.drawString(x, cur_y, line)
            line = ""
            cur_y -= line_height
            continue
        test = line + ch
        if c.stringWidth(test, font, size) > max_width:
            c.drawString(x, cur_y, line)
            line = ch
            cur_y -= line_height
        else:
            line = test
    if line:
        c.drawString(x, cur_y, line)
